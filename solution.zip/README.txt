TODO: add information about contributions of team member(s)

MS1:
    Andy Nguyen: implemented uint256_create_from_u32 and uint256_get_bits
    Barna Marczali: implemented uint256_create and uint256_is_bit_set