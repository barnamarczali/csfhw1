TODO: add information about contributions of team member(s)

MS1:
    Andy Nguyen: implemented uint256_create_from_u32 and uint256_get_bits.
    Barna Marczali: implemented uint256_create and uint256_is_bit_set.

MS2:
    Andy Nguyen: implemented uint256_create_from_hex, uint256_format_as_hex, 
    and uint256_lshift, as well as their respective unit tests.
    Barna Marczali: implemented uint256_add, uint256_sub, uint256_negate, and 
    uint256_mul, as well as their respective unit tests.